#-------------------------------------------------#
# Title: To Do List
# Dev:   Jeffrey Katayama
# Date:  08/09/2018
# Desc: To Do List Dictionary
# ChangeLog: JK, 08/08/2018, Created file
#-------------------------------------------------#

'''
1. Create a text file called Todo.txt using the following data:
Clean House,low
Pay Bills,high
2. When the program starts, load each row of data from the ToDo.txt text file into a Python dictionary. (The data will be stored like a row in a table.)
Tip: You can use a for loop to read a single line of text from the file and then place the data into a new dictionary object.
3. After you get the data in a Python dictionary, Add the new dictionary “row” into a Python list object (now the data will be managed as a table).
4. Display the contents of the List to the user.
5. Allow the user to Add or Remove tasks from the list using numbered choices. Something like this would work:
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
6. Save the data from the table into the Todo.txt file when the program exits.
'''

# Create todo.txt file
txtTodo = open("C:\\_PythonClass\\todo.txt", "w")
txtTodo.write("Clean House,low\n")
txtTodo.write("Pay Bills,high\n")
# Close todo.txt file

# Open todo.txt in read mode
txtTodo = open("C:\\_PythonClass\\todo.txt", "r")
# Create dictionary
dictTodo = {}
# Create list
listTodo = []
#Add rows in text file to dictionary
for row in txtTodo:
    data = row.split(",")
    dictTodo = {"task": data[0].strip().lower(), "priority": data[1].strip().lower()}
    listTodo.append(dictTodo)
# Close text file
txtTodo.close()

# Create menu
while(True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    choice = input("Please enter a number to select an option: ")
    # Display current list
    if(choice == '1'):
        print("Your current to do list is: ")
        for row in listTodo:
                    print(row)
    # Add new item to list
    elif(choice == '2'):
        task2 = input("Enter a task here: ")
        if task2.lower() in dictTodo["task"]:
            print("Sorry that task already exists.")
        else:
            priority2 = input("Enter the priority here: ")
            dictTodo = {"task": task2, "priority": priority2}
            listTodo.append(dictTodo)
            print(task2, "has been added")
    # Delete item from list
    elif(choice== '3'):
        deltask = input("Enter the task to be deleted: ")
        if deltask in dictTodo["task"]:
            listTodo.remove(dictTodo)
            print(deltask, "has been deleted.")
        else:
            print("Sorry that task does not exist.")
    # Save data to text file
    elif(choice== '4'):
        txtTodo = open("C:\\_PythonClass\\todo.txt", "w")
        txtTodo.write("task" + " -> " + "priority" + "\n")
        for dictTodo in listTodo:
            txtTodo.write(str(dictTodo["task"])+" -> "+str(dictTodo["priority"])+"\n")
        # Close todo.txt file
        txtTodo.close()
        print("Your data has been saved.")
    # Exit program
    elif(choice== '5'):break
    # Create option for invalid choice
    else:
        print("Please select a valid option")


