#-------------------------------------------------#
# Title: To Do List
# Dev:   Jeffrey Katayama
# Date:  08/18/2018
# Desc: To Do List Functions
# ChangeLog: JK, 08/18/2018, Modified file for functions and class
#-------------------------------------------------#

'''
1.	Make function for code that loads each row of data from txt file into dictionary and adds to a list
2.	Make function for code that displays contents of list
3.	Make function for code that allows user to add or remove tasks from the list
4.	Make function for code that saves data into txt file
5.	Make a class to hold the functions
'''

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Processing --#
objFileName = "C:\_PythonClass\Todo.txt"
strData = ""
dicRow = {}
lstTable = []

class taskfunctions(object):
    "Functions needed to create list of to do tasks"

    @staticmethod
    def LoadData(objFileName):
        """Loads data from text file"""
        objFile = open(objFileName, "r")
        for line in objFile:
            strData = line.split(",")  # readline() reads a line of the data into 2 elements
            dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
            lstTable.append(dicRow)
        objFile.close()
        return lstTable

    @staticmethod
    def ShowList():
        """Displays current list of tasks"""
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        return lstTable

    @staticmethod
    def AddTask(strTask, strPriority, lstTable):
        """Adds new task to list"""
        dicRow = {"Task":strTask,"Priority":strPriority}
        lstTable.append(dicRow)
        print("Current Data in table:")
        for dicRow in lstTable:
            print(dicRow)
        #4a Show the current items in the table
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        return lstTable


    @staticmethod
    def DeleteTask(strKeyToRemove, lstTable):
        """Deletes task from list"""
        # 5a-Allow user to indicate which row to delete
        blnItemRemoved = False  # Creating a boolean Flag
        intRowNumber = 0
        while (intRowNumber < len(lstTable)):
            if (strKeyToRemove == str(
                    list(dict(lstTable[intRowNumber]).values())[0])):  # the values function creates a list!
                del lstTable[intRowNumber]
                blnItemRemoved = True
            # end if
            intRowNumber += 1
        # end for loop
        # 5b-Update user on the status
        if (blnItemRemoved == True):
            print("The task was removed.")
        else:
            print("I'm sorry, but I could not find that task.")
        # 5c Show the current items in the table
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        return lstTable

    @staticmethod
    def SaveData(objFileName):
        """Saves data to text file"""
        #5a Show the current items in the table
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        #5b Ask if they want to save that data
        if("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
            objFile = open(objFileName, "w")
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objFile.close()
            input("Data saved to file! Press the [Enter] key to return to menu.")
        else:
            input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")
        return lstTable

# -- presentation (I/0) code --

# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
taskfunctions.LoadData(objFileName)

# Step 2
# Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()#adding a new line
    # Step 3
    # Show the current items in the table
    if (strChoice.strip() == '1'):
        taskfunctions.ShowList()
        continue
    # Step 4
    # Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        strTask = str(input("What is the task? - ")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        taskfunctions.AddTask(strTask, strPriority, lstTable)
        continue
    # Step 5
    # Remove a new item to the list/Table
    elif(strChoice == '3'):
        strKeyToRemove = input("Which TASK would you like removed? - ")
        taskfunctions.DeleteTask(strKeyToRemove, lstTable)
        continue
    # Step 6
    # Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        taskfunctions.SaveData(objFileName)
        continue
    # Step 7
    # Exit program
    elif (strChoice == '5'):
        break #and Exit the program

